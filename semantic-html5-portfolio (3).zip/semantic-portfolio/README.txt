SEMANTIC HTML5 PORTFOLIO

Pages:
- index.html: Home
- about.html: About
- projects.html: Projects
- contact.html: Contact
- css/styles.css: shared responsive styling

HOW TO USE
1. Extract the ZIP file.
2. Open the folder in VS Code.
3. Replace "Your Name", college, project descriptions, and other sample details.
4. Open index.html in a browser, or use the VS Code Live Server extension.
5. Add real project repository/demo links and your preferred contact details.

ACCESSIBILITY FEATURES
- Semantic header, nav, main, section, article, and footer landmarks.
- Skip-to-content link.
- Correct heading hierarchy and explicit form labels.
- Keyboard-visible focus styles.
- Native required and email validation.
- Current-page navigation state with aria-current.
- Responsive layout and reduced-motion preference support.

IMPORTANT
The contact form is an accessible front-end form only. It will not deliver messages until
you connect it to a server endpoint or a form-handling service.

A Lighthouse score of 100 cannot be guaranteed from source code alone. Run Lighthouse
in Chrome after replacing placeholders, checking all links, and testing the site. Also
test keyboard-only navigation and a screen reader.
